package com.example.fragmentcommunicationanimation;

public interface ContactDetailsListener
{
    void onBackFromDetails();
}
package com.example.fragmentcommunicationanimation;

public interface ContactFormListener
{
    void onContactAdded(String firstName, String lastName, String phoneNumber);
}